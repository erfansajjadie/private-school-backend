<footer class="hidden-print">
    <div class="pull-left">
        پنل مدیریت <a href="https://private-school.ir" target="_blank">Private School</a>
    </div>
    <div class="clearfix"></div>
</footer>
