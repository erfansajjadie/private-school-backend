@extends('layouts.app', ['body_class' => 'inner-page'])
@section('title', $user->fullname)
@section('content')
<div class="header-page">
    <div class="container">
        <nav class="breadcrumbs">
            <a href="{{route('home')}}">خانه</a>
            <span>
                {{$user->fullname}}
            </span>
        </nav>

    </div>
</div>
<section>
    <div class="container">
        <div class="post-faculty">
            <div class="row">
                <div class="col-md-3">
                    <img src="{{asset('storage/' . $user->profile_image)}}" alt="{{$user->fullname}}">
                </div>
                <div class="col-md-4">
                    <h2 class="mb-4">{{$user->fullname}}</h2>
                    <h6 class="mb-4">نام کاربری: {{$user->user_name}}</h6>
                    <span>حوزه تدریس:</span>
                    <h5 class="mt-2 mb-4">{{$user->category->name ?? ""}}</h5>
                    <div class="social">
                        <button class="btn btn-lg btn-light btn-social">
                            @if($user->is_private === 0)
                                <i class="fa fa-fw fa-user-alt"></i>
                                صفحه عمومی
                            @else
                                <i class="fa fa-fw fa-lock"></i>
                                صفحه خصوصی
                            @endif
                        </button>
                    </div>
                    <a href="" class="btn btn-success" >دنبال کردن</a>
                </div>
            </div>
            <div class="title-side mt-5">
                <h3 class="title">درباره استاد</h3>
            </div>
            <div class="text-more">
                <div class="content">
                    <p>مدت بیش از 10 سال است که بطور مستمر و تخصصی در حوزه دیجیتال مارکتینگ و SEO حضور دارند ، در این مدت با شرکت ها و برندهای معتبری در بخش های ، دیجیتال مارکتینگ ، Technical SEO ، مدیریت محتوا و کمپین های اینترنتی همکاری نموده اند ، با توجه به تسلط به به بخش برنامه نویسی و راه اندازی وب سایت های اینترنتی و مدیریت آنها (برپایه زبان php و یا CMS های آماده مانند wordpress)، نسبت به پیاده سازی فرایندهای فنی SEO&nbsp; (به صورت on-site و (off-site در پروژه ها اقدام می نمایند. و الگوی Product Owner فرایند SEO را در تعدادی از پروژه های مختلف پیاده سازی و مدیریت کرده اند</p><p><strong>تجارب دیجیتال مارکتینگ:&nbsp;</strong></p><p>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>گروه شرکت های طرفه نگار</strong> مدیریت و آموزش و نگهداری بخش SEO وب سایت های زیرمجموعه&nbsp; از سال 1395 تاکنون torfehnegar.com spad.ir rahinbesun.ir</p><p>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>شرکت مهندسی نرم افزار هلو</strong> مدیریت بخش SEO و دیجیتال مارکتینگ وب سایت و ابزارهای زیر مجموعه از سال 1397 تاکنون holoo.co.ir myholoo.com holoostore.com</p><p>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>شرکت VCG </strong>مشاور SEO و دیجیتال مارکتینگ از سال 1399 تاکنون vcreativeg.com</p><p>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>فروشگاه اینترنتی آلبرتیکا</strong> مدیریت بخش دیجیتال مارکتینگ و SEO از سال 1398 تاکنون albertika.com&nbsp;</p><p><strong>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; شرکت داتیس</strong></p><p>مشاور دیجیتال مارکتینگ و SEO وب سایت از سال 1399 تاکنون dateesco.com</p><p>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>وب سایت Carmelito</strong></p><p>مشاور دیجیتال مارکتینگ و SEO وب سایت از سال 1400 carmelito.ir.</p>
                </div>
            </div>
        </div>
        <div class="title-side">
            <h3 class="title"> دور های آموزشی اخیر {{$user->fullname}}</h3>
        </div>
        <div class="row">
            @foreach($user->courses as $course)
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="item-course">
                        @if($course->discount !== 0)
                            <button class="btn favorite js-login" data-toggle="tooltip" data-placement="top" title="افزودن به نشان شده‌ها">
                                <span>{{$course->discount_percent()}}%</span>
                            </button>
                        @endif
                        <a href="{{route('course-details', $course->id)}}" class="thumb"
                           style="background-image:url('{{asset('storage/'. $course->image)}}');"></a>
                        <h5 class="title">
                            <a href="{{route('course-details', $course->id)}}">{{$course->name}}</a>
                        </h5>
                        <div class="content">
                            <div><i class="fas fa-fw fa-user ml-1"></i>{{$course->user->user_name}}</div>
                            <div class="mt-2">
                                <i class="fas fa-fw fa-money-bill ml-1"></i>
                                <span class="format-number">{{$course->price()}}</span> تومان
                                @if($course->discount !== 0)
                                    <del class="text-muted text-sm-left  format-number">{{$course->price}}</del>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
        <div class="title-side">
            <h3 class="title"> پست های اخیر {{$user->fullname}}</h3>
        </div>
        <div class="row">
            @foreach($user->posts as $post)
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="item-course">
                        <a href="{{route('course-details', $post->id)}}" class="thumb"
                           style="background-image:url('{{asset('storage/'. $post->images()->first()->image)}}');"></a>
                        <h3 class="title">
                            <a href="{{route('course-details', $post->id)}}">{{$post->title}}</a>
                        </h3>
                        <p class = 'content'>
                            {{\Illuminate\Support\Str::limit($post->description, 100, '...')}}
                        </p>
                        <div class="content">
                            <div><i class="fas fa-fw fa-calendar ml-1"></i>{{$post->date()}}</div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endsection
