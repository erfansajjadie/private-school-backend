<footer class="footer">
    <div class="upper">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-lg-5 mb-5 mb-lg-0">
                    <div class="logo"></div>
                    <div class="info-text">
                        آموزشگاه بازارسازان، یکی از اعضای گروه TMBA است. خدمات گروه TMBA ، تحت مدیریت پرویز درگی و متمرکز بر آموزش، مشاوره، تحقیق و نشر در حوزه بازاریابی و فروش است. ماهیت این خدمات، شرایطی را فراهم ساخته که گروه TMBA همواره با چالشها و مسائل بازار ایران سر و کار داشته و به سفارش کارفرمایان خود، در پی راهکارهای هوشمندانه و کارآمد باشد.
                    </div>
                    <div class="d-flex justify-content-between">
                        <div>
                            <i class="fas fa-phone-square"></i>
                            <span>تلفن</span>
                            <a href="tel:02166028401" class="ltr">021 - 66028401 - 4</a>
                        </div>
                        <div>
                            <a class="fab fa-2x fa-fw fa-linkedin-in ml-2" href="https://www.linkedin.com/in/bazarsazan1/" target="_blank"></a>
                            <a class="fab fa-2x fa-fw fa-telegram-plane ml-2" href="https://www.t.me/parvizdargi/" target="_blank"></a>
                            <a class="fab fa-2x fa-fw fa-instagram" href="https://www.instagram.com/bazarsazan1/" target="_blank"></a>
                        </div>
                    </div>
                </div>
                <nav class="col-xl-3 col-lg-4 col-md-6 mb-5 mb-md-0">
                    <h3 class="main-title">وبسایت‌های ما</h3>
                    <ul class="list">
                        <li><a href="http://www.tmba.ir/" target="_blank">پرتال TMBA</a></li>
                        <li><a href="https://www.bazarshenasan.com/" target="_blank">مرکز استعدادشناسی و کاریابی بازارشناسان</a></li>
                        <li><a href="http://www.marketingshop.ir/" target="_blank">فروشگاه کتاب بازاریابی</a></li>
                        <li><a href="http://marketing-research.ir/" target="_blank">دپارتمان تحقیقات بازاریابی</a></li>
                        <li><a href="/bazaryad" target="_blank">سامانه آموزش آنلاین بازاریاد</a></li>
                    </ul>
                </nav>
                <div class="col-lg-3 col-md-6">
                    <div class="row">
                        <div class="col-6 col-md-12">
                            <div class="box">
                                <a href="http://tmba.ir/" target="_blank" class="mb-1">
                                    <img src="/images/logo/tmba.png" alt="" title="TMBA">
                                </a>
                                <a href="http://tmba.ir/tmba_catalogue.pdf" target="_blank" class="btn-block">
                                    <i class="fas fa-download"></i> دانلود کاتالوگ TMBA
                                </a>
                            </div>
                        </div>
                        <div class="col-6 col-md-12">
                            <div class="box">
                                <img src="/images/logo/tvto.png" alt="" title="مجوز از سازمان آموزش فنی و حرفه‌ای">
                                <div class="mt-1">دارای مجوز از سازمان آموزش فنی و حرفه‌ای کشور</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright">
        <div class="container">
            <div class="box">
                <div>کلیه حقوق این سایت متعلق به شرکت <a href="http://tmba.ir/" target="_blank">TMBA</a> می‌باشد.</div>
                <a href="/rules">قوانین ثبت نام</a>
            </div>
        </div>
    </div>
</footer>
