<header class="header">
    <div class="upper">
        <div class="container">
            <div class="inner">
                <a href="/">
                    <h1 class="logo">
                        سامانه private school
                    </h1>
                    <span>دارای مجوز از سازمان آموزش فنی و حرفه‌ای کشور</span>
                </a>
                <div class="info">
                    <div class="box">
                        <i class="fas fa-phone-volume"></i>
                        <a href="tel:02166028401" class="ltr">021 - 66028401-4</a>
                    </div>
                    <div class="box">
                        <i class="far fa-envelope"></i>
                        <a href="mailto:private-school@gmail.com">private-school@gmail.com</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="lower">
        <div class="container">
            <div class="inner">
                <div class="hamburger">
                    <div class="box">
                    </div>
                </div>
                <nav class="all-menu">
                    <ul class="main-menu navbar-nav">
                        <li class="nav-item active">
                            <a class="nav-link" href="{{route('home')}}">صفحه اصلی</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{route('courses-list')}}">دوره های آموزشی</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{route('users-list')}}">اساتید</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{route('posts-list')}}">مطالب کاربران</a>
                        </li>
                    </ul>
                    <ul class="side-options navbar-nav">
                        <li class="nav-item">
                            <a href="https://marketingschool.ir/user/certificate">
                                <i class="fas fa-certificate"></i>
                                <span>استعلام گواهینامه</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="https://marketingschool.ir/calender-course/calender/pdf">
                                <i class="fas fa-calendar"></i>
                                <span>دانلود تقویم آموزشی</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="https://marketingschool.ir/articles">
                                <i class="fas fa-download"></i>
                                <span>مقالات آموزشی</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="/cooperate">
                                <i class="fas fa-briefcase"></i>
                                <span>همکاری با ما</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="/about-us">
                                <i class="fas fa-info-circle"></i>
                                <span>درباره ما</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="/contact-us">
                                <i class="fas fa-envelope-open-text"></i>
                                <span>تماس با ما</span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <nav class="user-menu">
                    <a href="https://marketingschool.ir/user/affiliate" class="btn btn-outline-main d-none d-sm-inline-block ml-3">سیستم کسب درآمد</a>
                    @guest
                        <button class="btn js-login" data-toggle="modal" data-target="#modalLogin">
                            <i class="fas fa-user-graduate"></i>
                            <span> ورود / ثبت نام </span>
                        </button>
                    @endguest
                    @auth
                        <button  class="btn js-panel">
                            <i class="fas fa-user-cog"></i>
                            <span>{{Auth::user()->user_name  ?? "ورود به پنل"}}</span>
                        </button>
                    @endauth
                </nav>
            </div>
        </div>
    </div>
</header>
